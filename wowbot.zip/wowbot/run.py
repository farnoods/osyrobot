from wowbot import WoWBot

WoWBot().run()
