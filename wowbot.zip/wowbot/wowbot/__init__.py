from .bot import WoWBot

__all__ = ['WoWBot']
