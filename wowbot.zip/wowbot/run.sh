#!/bin/bash
python3.6 -u run.py